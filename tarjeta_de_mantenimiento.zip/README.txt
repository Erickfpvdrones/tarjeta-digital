Instrucciones rápidas para publicar esta tarjeta digital (gratis)

Archivos incluidos:
- index.html  -> página lista para subir
- README.txt  -> este archivo
- (Opcional) logo.jpg -> pon aquí tu logotipo con ese nombre si lo tienes

Método 1 — Netlify Drop (rápido, sin Git ni configuraciones)
1. Comprime esta carpeta en .zip o arrástrala tal cual.
2. Ve a https://app.netlify.com/drop  (puedes usar el enlace o buscar 'Netlify Drop').
3. Arrastra la carpeta (con index.html en la raíz) al área de Drop. Netlify te dará una URL temporal tipo https://something.netlify.app
4. Si quieres conservar la URL, crea una cuenta gratis en Netlify y vuelve a subir el proyecto (o pulsa "Sign up" cuando Netlify lo pida).

Método 2 — GitHub Pages (recomendado si quieres control y una URL permanente)
1. Crea una cuenta en https://github.com si no tienes.
2. Crea un nuevo repositorio público (por ejemplo: mantenimiento-qro-site).
3. Sube los archivos (index.html y logo.jpg) al repositorio (puedes arrastrarlos en la interfaz web).
4. En la pestaña "Settings" -> "Pages", configura la rama principal (main) y la carpeta "/" como fuente y guarda. GitHub te ofrecerá la URL username.github.io/repo (o username.github.io si nombras el repo username.github.io).
5. Espera unos minutos y abre la URL que GitHub Pages te indique.

Notas importantes:
- Si tienes un logotipo, renómbralo a 'logo.jpg' y colócalo en la misma carpeta antes de subir. Si no, la página seguirá funcionando pero sin imagen.
- Para usar un dominio personalizado (ej. mipagina.com) necesitas ajustar DNS; Netlify y GitHub Pages soportan dominios personalizados gratuitamente (solo el dominio debe comprarse o conseguirse gratis en otros proveedores).
- Si quieres, puedo generar una versión sin el <img> para evitar errores si no subes logo.jpg.
